import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsuarioComponent } from './usuario/usuario.component';
import { BuscarVuelosComponent } from './buscar-vuelos/buscar-vuelos.component';
import { ContenedorComponent } from './contenedor/contenedor.component';

const routes: Routes = [
  { path:'', component: UsuarioComponent},
  { path: '', component: BuscarVuelosComponent},
  { path: '',component: ContenedorComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
