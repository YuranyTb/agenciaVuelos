import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuscarVuelosComponent } from './buscar-vuelos.component';

describe('BuscarVuelosComponent', () => {
  let component: BuscarVuelosComponent;
  let fixture: ComponentFixture<BuscarVuelosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BuscarVuelosComponent]
    });
    fixture = TestBed.createComponent(BuscarVuelosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
