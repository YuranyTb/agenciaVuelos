import { Component } from '@angular/core';

@Component({
  selector: 'login',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent {
  
  constructor(){}
  ngOnInit(): void{
    
  }

}


