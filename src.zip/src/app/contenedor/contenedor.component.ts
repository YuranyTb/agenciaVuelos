import { Component } from '@angular/core';

@Component({
  selector: 'contenedor',
  templateUrl: './contenedor.component.html',
  styleUrls: ['./contenedor.component.css']
})
export class ContenedorComponent {

}
