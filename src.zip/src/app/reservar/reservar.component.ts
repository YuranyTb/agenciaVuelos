import { Component } from '@angular/core';

@Component({
  selector: 'reservar',
  templateUrl: './reservar.component.html',
  styleUrls: ['./reservar.component.css']
})
export class ReservarComponent {
  alerta: String;

  constructor() {
    this.alerta = 'tiquet 56'
}
}
